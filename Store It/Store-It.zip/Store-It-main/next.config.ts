import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  env: {
    NEXTAUTH_URL: process.env.NEXTAUTH_URL,
    NEXTAUTH_SECRET: process.env.NEXTAUTH_SECRET,

    AUTH_COGNITO_ID: process.env.AUTH_COGNITO_ID,
    AUTH_COGNITO_SECRET: process.env.AUTH_COGNITO_SECRET,
    AUTH_COGNITO_ISSUER: process.env.AUTH_COGNITO_ISSUER,
    AUTH_COGNITO_DOMAIN: process.env.AUTH_COGNITO_DOMAIN,

    APP_AWS_REGION: process.env.APP_AWS_REGION,
    APP_S3_BUCKET_NAME: process.env.APP_S3_BUCKET_NAME,
    APP_DYNAMODB_FILES_TABLE: process.env.APP_DYNAMODB_FILES_TABLE,

    APP_AWS_ACCESS_KEY_ID: process.env.APP_AWS_ACCESS_KEY_ID,
    APP_AWS_SECRET_ACCESS_KEY: process.env.APP_AWS_SECRET_ACCESS_KEY,
  },
};

export default nextConfig;