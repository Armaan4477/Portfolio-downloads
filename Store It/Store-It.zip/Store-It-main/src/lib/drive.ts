export type FileVersion = {
  versionId: string;
  objectKey: string;
  size: number;
  mimeType: string;
  createdAt: string;
};

export type DriveItem = {
  userId: string;
  fileId: string;
  name: string;
  entityType?: "file" | "folder";
  parentId?: string | null;
  deletedAt?: string | null;
  mimeType?: string;
  size?: number;
  objectKey?: string;
  latestVersion?: number;
  versions?: FileVersion[];
  thumbnailKey?: string;
  thumbnailStatus?: "PENDING" | "READY" | "FAILED";
  createdAt: string;
};

export function toSafeFileName(fileName: string) {
  return fileName.replace(/[^a-zA-Z0-9._-]/g, "_");
}

export function isFolder(item: DriveItem) {
  return item.entityType === "folder";
}

export function isFile(item: DriveItem) {
  return !item.entityType || item.entityType === "file";
}
