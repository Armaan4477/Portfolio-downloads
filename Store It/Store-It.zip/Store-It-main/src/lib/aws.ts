import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { S3Client } from "@aws-sdk/client-s3";
import { getServerEnv } from "@/lib/env";

let cached:
  | {
      s3Client: S3Client;
      dynamoDocClient: DynamoDBDocumentClient;
      bucketName: string;
      tableName: string;
    }
  | undefined;

export function getAwsClients() {
  if (cached) {
    return cached;
  }

  const env = getServerEnv();

  const credentials =
    env.APP_AWS_ACCESS_KEY_ID && env.APP_AWS_SECRET_ACCESS_KEY
      ? {
          accessKeyId: env.APP_AWS_ACCESS_KEY_ID,
          secretAccessKey: env.APP_AWS_SECRET_ACCESS_KEY,
          sessionToken: env.APP_AWS_SESSION_TOKEN,
        }
      : undefined;

  const s3Client = new S3Client({
    region: env.APP_AWS_REGION,
    credentials,
  });

  const dynamoClient = new DynamoDBClient({
    region: env.APP_AWS_REGION,
    credentials,
  });

  cached = {
    s3Client,
    dynamoDocClient: DynamoDBDocumentClient.from(dynamoClient),
    bucketName: env.APP_S3_BUCKET_NAME,
    tableName: env.APP_DYNAMODB_FILES_TABLE,
  };

  return cached;
}
