import { z } from "zod";

const envSchema = z.object({
  APP_AWS_REGION: z.string().min(1),
  APP_S3_BUCKET_NAME: z.string().min(1),
  APP_DYNAMODB_FILES_TABLE: z.string().min(1),
  APP_AWS_ACCESS_KEY_ID: z.string().optional(),
  APP_AWS_SECRET_ACCESS_KEY: z.string().optional(),
  APP_AWS_SESSION_TOKEN: z.string().optional(),
});

let hasLoggedEnvResolution = false;

export function getServerEnv() {
  const normalizedEnv = {
    APP_AWS_REGION:
      process.env.APP_AWS_REGION ?? process.env.AWS_REGION ?? process.env.AWS_DEFAULT_REGION,
    APP_S3_BUCKET_NAME: process.env.APP_S3_BUCKET_NAME ?? process.env.S3_BUCKET_NAME,
    APP_DYNAMODB_FILES_TABLE:
      process.env.APP_DYNAMODB_FILES_TABLE ?? process.env.DYNAMODB_FILES_TABLE,
    APP_AWS_ACCESS_KEY_ID: process.env.APP_AWS_ACCESS_KEY_ID,
    APP_AWS_SECRET_ACCESS_KEY: process.env.APP_AWS_SECRET_ACCESS_KEY,
    APP_AWS_SESSION_TOKEN: process.env.APP_AWS_SESSION_TOKEN,
  };

  if (!hasLoggedEnvResolution) {
    hasLoggedEnvResolution = true;
    console.info("[env] resolved server environment", {
      regionKey: process.env.APP_AWS_REGION
        ? "APP_AWS_REGION"
        : process.env.AWS_REGION
          ? "AWS_REGION"
          : process.env.AWS_DEFAULT_REGION
            ? "AWS_DEFAULT_REGION"
            : "missing",
      bucketKey: process.env.APP_S3_BUCKET_NAME ? "APP_S3_BUCKET_NAME" : "S3_BUCKET_NAME",
      tableKey: process.env.APP_DYNAMODB_FILES_TABLE
        ? "APP_DYNAMODB_FILES_TABLE"
        : "DYNAMODB_FILES_TABLE",
    });
  }

  return envSchema.parse(normalizedEnv);
}
