import { getServerSession, type NextAuthOptions } from "next-auth";
import Cognito from "next-auth/providers/cognito";

const cognitoDomain = process.env.AUTH_COGNITO_DOMAIN;
const cognitoBase = cognitoDomain
  ? cognitoDomain.startsWith("http")
    ? cognitoDomain
    : `https://${cognitoDomain}`
  : undefined;
const cognitoAuthorizationUrl = cognitoBase
  ? new URL("/oauth2/authorize", cognitoBase).toString()
  : undefined;

export const authOptions: NextAuthOptions = {
  session: {
    strategy: "jwt",
  },
  providers: [
    Cognito({
      clientId: process.env.AUTH_COGNITO_ID ?? "",
      clientSecret: process.env.AUTH_COGNITO_SECRET ?? "",
      issuer: process.env.AUTH_COGNITO_ISSUER ?? "",
      authorization: cognitoAuthorizationUrl
        ? {
            url: cognitoAuthorizationUrl,
            params: {
              scope: "openid email",
            },
          }
        : {
            params: {
              scope: "openid email",
            },
          },
    }),
  ],
  callbacks: {
    async jwt({ token, profile }) {
      if (profile && "sub" in profile && typeof profile.sub === "string") {
        token.userId = profile.sub;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id =
          typeof token.userId === "string"
            ? token.userId
            : typeof token.sub === "string"
              ? token.sub
              : "";
      }
      return session;
    },
  },
};

export function getAuthSession() {
  return getServerSession(authOptions);
}
