"use client";

import {
  isFile,
  isFolder,
  type DriveItem,
  type FileVersion,
} from "@/lib/drive";
import Link from "next/link";
import { signIn, signOut, useSession } from "next-auth/react";
import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react";

type UploadUrlResponse = {
  fileId: string;
  uploadUrl: string;
};

type FolderCreateResponse = {
  fileId: string;
};

type SelectedUploadFile = {
  file: File;
  relativePath: string;
};

type FolderCrumb = {
  id: string | null;
  name: string;
};

type FolderOption = {
  fileId: string;
  name: string;
  parentId?: string | null;
};

type SortBy = "name" | "size" | "type" | "date";
type SortOrder = "asc" | "desc";

type ActionMenuPosition = {
  top: number;
  left: number;
};

const ACTION_MENU_WIDTH = 320;

export function DriveClient() {
  const { data: session, status } = useSession();
  const [items, setItems] = useState<DriveItem[]>([]);
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
  const [breadcrumbs, setBreadcrumbs] = useState<FolderCrumb[]>([
    { id: null, name: "My Drive" },
  ]);
  const [uploading, setUploading] = useState(false);
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [uploadTotal, setUploadTotal] = useState(0);
  const [uploadCompleted, setUploadCompleted] = useState(0);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isSortOpen, setIsSortOpen] = useState(false);
  const [sortBy, setSortBy] = useState<SortBy>("date");
  const [sortOrder, setSortOrder] = useState<SortOrder>("desc");
  const [creatingFolder, setCreatingFolder] = useState(false);
  const [folderName, setFolderName] = useState("");
  const [isCreateFolderOpen, setIsCreateFolderOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedVersionsFile, setSelectedVersionsFile] = useState<DriveItem | null>(
    null,
  );
  const [versions, setVersions] = useState<FileVersion[]>([]);
  const [movingItem, setMovingItem] = useState<DriveItem | null>(null);
  const [actionMenuItem, setActionMenuItem] = useState<DriveItem | null>(null);
  const [actionMenuPosition, setActionMenuPosition] = useState<ActionMenuPosition | null>(null);
  const [moveTargetParentId, setMoveTargetParentId] = useState<string>("ROOT");
  const [folderOptions, setFolderOptions] = useState<FolderOption[]>([]);
  const [moving, setMoving] = useState(false);
  const [deleteCandidate, setDeleteCandidate] = useState<DriveItem | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const folderInputRef = useRef<HTMLInputElement | null>(null);

  const isAuthenticated = status === "authenticated" && !!session?.user?.id;

  const refreshFiles = useCallback(async () => {
    if (!isAuthenticated) {
      setItems([]);
      return;
    }

    const query = searchTerm.trim()
      ? `?search=${encodeURIComponent(searchTerm.trim())}`
      : currentFolderId
        ? `?parentId=${encodeURIComponent(currentFolderId)}`
        : "?parentId=";
    const res = await fetch(`/api/files${query}`, { cache: "no-store" });

    if (!res.ok) {
      setMessage("Could not load files.");
      return;
    }

    const data = (await res.json()) as { items: DriveItem[] };
    setItems(data.items);
  }, [currentFolderId, isAuthenticated, searchTerm]);

  useEffect(() => {
    void refreshFiles();
  }, [refreshFiles]);

  const totalStorage = useMemo(
    () =>
      items
        .filter(isFile)
        .reduce((acc, file) => acc + (file.size ?? 0), 0),
    [items],
  );

  const uploadProgressPercent = useMemo(() => {
    if (uploadTotal <= 0) {
      return 0;
    }

    return Math.min(100, Math.round((uploadCompleted / uploadTotal) * 100));
  }, [uploadCompleted, uploadTotal]);

  const sortedItems = useMemo(() => {
    const list = [...items];

    list.sort((a, b) => {
      let result = 0;

      if (sortBy === "name") {
        result = a.name.localeCompare(b.name);
      }

      if (sortBy === "size") {
        const aSize = isFolder(a) ? -1 : (a.size ?? 0);
        const bSize = isFolder(b) ? -1 : (b.size ?? 0);
        result = aSize - bSize;
      }

      if (sortBy === "type") {
        const aType = isFolder(a) ? "folder" : (a.mimeType ?? "file");
        const bType = isFolder(b) ? "folder" : (b.mimeType ?? "file");
        result = aType.localeCompare(bType);
      }

      if (sortBy === "date") {
        result = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      }

      if (result === 0) {
        result = a.name.localeCompare(b.name);
      }

      return sortOrder === "asc" ? result : -result;
    });

    return list;
  }, [items, sortBy, sortOrder]);

  function setFolderInputDirectoryAttributes() {
    const folderInput = folderInputRef.current as
      | (HTMLInputElement & {
          webkitdirectory?: boolean;
          directory?: boolean;
          mozdirectory?: boolean;
        })
      | null;

    if (!folderInput) {
      return null;
    }

    folderInput.multiple = true;
    folderInput.setAttribute("webkitdirectory", "");
    folderInput.setAttribute("directory", "");
    folderInput.setAttribute("mozdirectory", "");
    folderInput.webkitdirectory = true;
    folderInput.directory = true;
    folderInput.mozdirectory = true;
    return folderInput;
  }

  useEffect(() => {
    setFolderInputDirectoryAttributes();
  }, []);

  useEffect(() => {
    if (uploading || uploadTotal <= 0) {
      return;
    }

    const timer = window.setTimeout(() => {
      setUploadTotal(0);
      setUploadCompleted(0);
    }, 10000);

    return () => {
      window.clearTimeout(timer);
    };
  }, [uploading, uploadTotal]);

  useEffect(() => {
    if (!message) {
      return;
    }

    const timer = window.setTimeout(() => {
      setMessage(null);
    }, 10000);

    return () => {
      window.clearTimeout(timer);
    };
  }, [message]);

  useEffect(() => {
    if (!actionMenuItem) {
      return;
    }

    function onEscape(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setActionMenuItem(null);
        setActionMenuPosition(null);
      }
    }

    function onClickOutside(event: MouseEvent) {
      const target = event.target as HTMLElement | null;
      if (target?.closest(".floating-action-menu") || target?.closest(".action-trigger")) {
        return;
      }

      setActionMenuItem(null);
      setActionMenuPosition(null);
    }

    window.addEventListener("keydown", onEscape);
    window.addEventListener("mousedown", onClickOutside);

    return () => {
      window.removeEventListener("keydown", onEscape);
      window.removeEventListener("mousedown", onClickOutside);
    };
  }, [actionMenuItem]);

  async function onSignIn() {
    await signIn("cognito");
  }

  async function onSignOut() {
    await signOut({ redirect: false });
    window.location.href = "/api/auth/cognito-signout";
  }

  async function uploadFileToParent(file: File, parentId: string | null) {
    const uploadUrlRes = await fetch("/api/files/upload-url", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        name: file.name,
        mimeType: file.type || "application/octet-stream",
        size: file.size,
        parentId,
      }),
    });

    if (!uploadUrlRes.ok) {
      throw new Error("Could not prepare upload");
    }

    const uploadPayload = (await uploadUrlRes.json()) as UploadUrlResponse;

    const s3Upload = await fetch(uploadPayload.uploadUrl, {
      method: "PUT",
      headers: {
        "Content-Type": file.type || "application/octet-stream",
      },
      body: file,
    });

    if (!s3Upload.ok) {
      throw new Error("Upload failed");
    }
  }

  async function onFileSelected(file: File | null) {
    if (!file || !isAuthenticated) {
      return;
    }

    setUploading(true);
    setUploadTotal(1);
    setUploadCompleted(0);
    setMessage(null);

    try {
      await uploadFileToParent(file, currentFolderId);
      setUploadCompleted(1);

      await refreshFiles();
      setMessage(`Uploaded ${file.name}`);
    } catch (error) {
      console.error(error);
      setMessage("Upload failed. Check AWS configuration and try again.");
    } finally {
      setUploading(false);
    }
  }

  async function onFolderSelected(files: SelectedUploadFile[]) {
    if (files.length === 0 || !isAuthenticated) {
      return;
    }

    setUploading(true);
    setUploadTotal(files.length);
    setUploadCompleted(0);
    setMessage(null);

    try {
      const folderIdByPath = new Map<string, string | null>();
      folderIdByPath.set("", currentFolderId);

      const ensureFolderPath = async (segments: string[]) => {
        if (segments.length === 0) {
          return currentFolderId;
        }

        let currentPath = "";
        let parentId = currentFolderId;

        for (const segment of segments) {
          currentPath = currentPath ? `${currentPath}/${segment}` : segment;
          const cachedId = folderIdByPath.get(currentPath);

          if (cachedId !== undefined) {
            parentId = cachedId;
            continue;
          }

          const createRes = await fetch("/api/folders", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              name: segment,
              parentId,
            }),
          });

          if (!createRes.ok) {
            throw new Error("Could not create folder structure");
          }

          const folderPayload = (await createRes.json()) as FolderCreateResponse;
          parentId = folderPayload.fileId;
          folderIdByPath.set(currentPath, parentId);
        }

        return parentId;
      };

      for (const selectedFile of files) {
        const file = selectedFile.file;
        const relativePath = selectedFile.relativePath || file.name;
        const segments = relativePath.split("/").filter(Boolean);
        const fileName = segments[segments.length - 1] ?? file.name;
        const parentSegments = segments.slice(0, -1);
        const parentId = await ensureFolderPath(parentSegments);
        const fileToUpload = fileName === file.name ? file : new File([file], fileName, { type: file.type });
        await uploadFileToParent(fileToUpload, parentId ?? null);
        setUploadCompleted((prev) => prev + 1);
      }

      await refreshFiles();
      setMessage(`Uploaded folder with ${files.length} file${files.length === 1 ? "" : "s"}.`);
    } catch (error) {
      console.error(error);
      setMessage("Folder upload failed. Check AWS configuration and try again.");
    } finally {
      setUploading(false);
    }
  }

  async function openFolderPicker() {
    const pickerApi = (window as Window & {
      showDirectoryPicker?: () => Promise<{
        name: string;
        values: () => AsyncIterable<{
          kind: "file" | "directory";
          name: string;
          getFile?: () => Promise<File>;
          values?: () => AsyncIterable<unknown>;
        }>;
      }>;
    }).showDirectoryPicker;

    if (pickerApi) {
      try {
        const rootHandle = await pickerApi();
        const selected: SelectedUploadFile[] = [];

        const walkDirectory = async (
          directoryHandle: {
            values: () => AsyncIterable<{
              kind: "file" | "directory";
              name: string;
              getFile?: () => Promise<File>;
              values?: () => AsyncIterable<unknown>;
            }>;
          },
          currentPath: string,
        ) => {
          for await (const entry of directoryHandle.values()) {
            if (entry.kind === "file" && entry.getFile) {
              const file = await entry.getFile();
              selected.push({
                file,
                relativePath: currentPath ? `${currentPath}/${file.name}` : file.name,
              });
            }

            if (entry.kind === "directory" && entry.values) {
              const nextPath = currentPath ? `${currentPath}/${entry.name}` : entry.name;
              await walkDirectory(
                { values: entry.values as () => AsyncIterable<{
                    kind: "file" | "directory";
                    name: string;
                    getFile?: () => Promise<File>;
                    values?: () => AsyncIterable<unknown>;
                  }> },
                nextPath,
              );
            }
          }
        };

        await walkDirectory(rootHandle, rootHandle.name);
        await onFolderSelected(selected);
        return;
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }

        console.error(error);
      }
    }

    const folderInput = setFolderInputDirectoryAttributes();
    folderInput?.click();
  }

  async function onCreateFolder() {
    if (!folderName.trim()) {
      setMessage("Folder name is required.");
      return;
    }

    setCreatingFolder(true);
    setMessage(null);

    try {
      const res = await fetch("/api/folders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: folderName.trim(),
          parentId: currentFolderId,
        }),
      });

      if (!res.ok) {
        throw new Error("Folder create failed");
      }

      setFolderName("");
      setIsCreateFolderOpen(false);
      await refreshFiles();
    } catch (error) {
      console.error(error);
      setMessage("Could not create folder.");
    } finally {
      setCreatingFolder(false);
    }
  }

  async function onOpenFolder(folder: DriveItem) {
    setMessage(null);
    setSearchTerm("");
    setCurrentFolderId(folder.fileId);

    try {
      const res = await fetch("/api/folders", { cache: "no-store" });

      if (!res.ok) {
        setBreadcrumbs((prev) => [...prev, { id: folder.fileId, name: folder.name }]);
        return;
      }

      const payload = (await res.json()) as { folders: FolderOption[] };
      const byId = new Map(payload.folders.map((entry) => [entry.fileId, entry]));

      const path: FolderCrumb[] = [];
      let current: FolderOption | undefined = byId.get(folder.fileId);

      while (current) {
        path.push({ id: current.fileId, name: current.name });
        current = current.parentId ? byId.get(current.parentId) : undefined;
      }

      setBreadcrumbs([{ id: null, name: "My Drive" }, ...path.reverse()]);
    } catch (error) {
      console.error(error);
      setBreadcrumbs((prev) => [...prev, { id: folder.fileId, name: folder.name }]);
    }
  }

  function onNavigateToCrumb(index: number) {
    const nextCrumbs = breadcrumbs.slice(0, index + 1);
    setBreadcrumbs(nextCrumbs);
    setCurrentFolderId(nextCrumbs[nextCrumbs.length - 1]?.id ?? null);
  }

  async function onDownload(fileId: string) {
    const res = await fetch(`/api/files/${fileId}/download-url`);

    if (!res.ok) {
      setMessage("Could not generate download link.");
      return;
    }

    const data = (await res.json()) as { downloadUrl: string };
    window.open(data.downloadUrl, "_blank", "noopener,noreferrer");
  }

  function getDescendantFolderIds(
    rootId: string,
    folders: FolderOption[],
  ) {
    const byParent = new Map<string, FolderOption[]>();

    for (const folder of folders) {
      const parentKey = folder.parentId ?? "ROOT";
      const current = byParent.get(parentKey) ?? [];
      current.push(folder);
      byParent.set(parentKey, current);
    }

    const descendants = new Set<string>();
    const stack = [rootId];

    while (stack.length > 0) {
      const current = stack.pop()!;
      const children = byParent.get(current) ?? [];

      for (const child of children) {
        descendants.add(child.fileId);
        stack.push(child.fileId);
      }
    }

    return descendants;
  }

  async function onStartMove(item: DriveItem) {
    setMessage(null);
    const res = await fetch("/api/folders", { cache: "no-store" });

    if (!res.ok) {
      setMessage("Could not load folders for move.");
      return;
    }

    const payload = (await res.json()) as { folders: FolderOption[] };
    const folders = payload.folders ?? [];

    const disallowed = new Set<string>([item.fileId]);
    if (isFolder(item)) {
      const descendants = getDescendantFolderIds(item.fileId, folders);
      for (const id of descendants) {
        disallowed.add(id);
      }
    }

    const available = folders.filter((folder) => !disallowed.has(folder.fileId));
    const normalizedCurrentParentId = item.parentId ?? null;
    const initialTarget =
      normalizedCurrentParentId === null ||
      available.some((folder) => folder.fileId === normalizedCurrentParentId)
        ? (normalizedCurrentParentId ?? "ROOT")
        : "ROOT";

    setFolderOptions(available);
    setMoveTargetParentId(initialTarget);
    setMovingItem(item);
  }

  async function onConfirmMove() {
    if (!movingItem) {
      return;
    }

    setMoving(true);

    const targetParentId = moveTargetParentId === "ROOT" ? null : moveTargetParentId;

    const res = await fetch(`/api/files/${movingItem.fileId}/move`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ targetParentId }),
    });

    if (!res.ok) {
      const payload = (await res.json().catch(() => null)) as
        | { error?: string }
        | null;
      setMessage(payload?.error ?? "Move failed.");
      setMoving(false);
      return;
    }

    setMovingItem(null);
    setFolderOptions([]);
    setMoveTargetParentId("ROOT");
    setMoving(false);
    setMessage(`Moved ${movingItem.name}.`);
    await refreshFiles();
  }

  function onRequestDelete(item: DriveItem) {
    setMessage(null);
    setDeleteCandidate(item);
  }

  async function onConfirmDelete() {
    if (!deleteCandidate) {
      return;
    }

    setDeleting(true);

    const res = await fetch(`/api/files/${deleteCandidate.fileId}`, {
      method: "DELETE",
    });

    if (res.ok) {
      const deletedName = deleteCandidate.name;
      setDeleteCandidate(null);
      setDeleting(false);
      setMessage(`Moved ${deletedName} to bin.`);
      await refreshFiles();
      return;
    }

    const payload = (await res.json().catch(() => null)) as
      | { error?: string }
      | null;
    setMessage(payload?.error ?? "Delete failed.");
    setDeleting(false);
  }

  async function onPreview(fileId: string) {
    const res = await fetch(`/api/files/${fileId}/preview-url`);

    if (!res.ok) {
      setMessage("Preview not available for this file type.");
      return;
    }

    const data = (await res.json()) as { previewUrl: string };
    window.open(data.previewUrl, "_blank", "noopener,noreferrer");
  }

  async function onViewVersions(item: DriveItem) {
    const res = await fetch(`/api/files/${item.fileId}/versions`);

    if (!res.ok) {
      setMessage("Could not load versions.");
      return;
    }

    const data = (await res.json()) as { versions: FileVersion[] };
    setSelectedVersionsFile(item);
    setVersions(data.versions);
  }

  async function onRestoreVersion(versionId: string) {
    if (!selectedVersionsFile) {
      return;
    }

    const res = await fetch(`/api/files/${selectedVersionsFile.fileId}/versions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ versionId }),
    });

    if (!res.ok) {
      setMessage("Could not restore selected version.");
      return;
    }

    setSelectedVersionsFile(null);
    setVersions([]);
    await refreshFiles();
  }

  if (status === "loading") {
    return (
      <main className="drive-shell">
        <section className="frame auth-card fade-in">
          <h1 className="title">Preparing your workspace</h1>
          <p className="subtitle">Checking your session with Cognito...</p>
        </section>
      </main>
    );
  }

  if (!isAuthenticated) {
    return (
      <main className="drive-shell">
        <section className="frame auth-card fade-in">
          <span className="auth-kicker">Store It</span>
          <h1 className="title" style={{ marginTop: "0.7rem" }}>
            Keep every file organized, searchable, and secure
          </h1>
          <p className="subtitle" style={{ maxWidth: "60ch" }}>
            Store It gives you a focused workspace on top of AWS. Upload files and
            folders, preview content instantly, recover deleted items from Bin, and
            manage version history without leaving one clean dashboard.
          </p>
          <button
            type="button"
            onClick={() => void onSignIn()}
            className="button button-primary fade-in-delay"
            style={{ marginTop: "1rem" }}
          >
            Continue with Cognito
          </button>
        </section>
      </main>
    );
  }

  return (
    <main className="drive-shell fade-in">
      <header className="frame glass top-bar">
        <div>
          <h1 className="title">My Drive</h1>
          <p className="subtitle">
            {session.user.email ?? "Signed in user"} • {items.length} items •{" "}
            {(totalStorage / 1024 / 1024).toFixed(2)} MB
          </p>
          <p className="meter">AWS S3 + DynamoDB index</p>
        </div>
        <div style={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
          <button
            type="button"
            className="button button-secondary"
            onClick={() => setIsSearchOpen((prev) => !prev)}
            aria-label="Toggle search"
            title="Search"
          >
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden="true"
            >
              <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" />
              <path d="M20 20L16.5 16.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </button>
          <button
            type="button"
            className="button button-secondary"
            onClick={() => setIsSortOpen((prev) => !prev)}
            aria-label="Toggle sorting"
            title="Sort"
          >
            Sort
          </button>
          <Link href="/bin" className="button button-secondary">
            Bin
          </Link>
          <button
            type="button"
            onClick={() => void onSignOut()}
            className="button button-secondary"
          >
            Sign out
          </button>
        </div>
      </header>

      {isSearchOpen ? (
        <section className="frame controls fade-in-delay" style={{ paddingTop: "0.85rem", paddingBottom: "0.85rem" }}>
          <div style={{ display: "grid", gap: "0.6rem" }}>
            <input
              type="text"
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
              placeholder="Search by name"
              className="input"
              style={{ width: "100%" }}
              autoFocus
            />
            <button
              type="button"
              className="button button-secondary"
              onClick={() => {
                setSearchTerm("");
                setIsSearchOpen(false);
              }}
            >
              Close
            </button>
          </div>
        </section>
      ) : null}

      {isSortOpen ? (
        <section className="frame controls fade-in-delay" style={{ paddingTop: "0.85rem", paddingBottom: "0.85rem" }}>
          <div className="sort-controls" style={{ display: "flex", gap: "0.6rem", alignItems: "center", flexWrap: "wrap" }}>
            <select
              className="input sort-select"
              value={sortBy}
              onChange={(event) => setSortBy(event.target.value as SortBy)}
              aria-label="Sort by"
            >
              <option value="name">Sort by name</option>
              <option value="size">Sort by size</option>
              <option value="type">Sort by type</option>
              <option value="date">Sort by date uploaded</option>
            </select>
            <select
              className="input sort-select"
              value={sortOrder}
              onChange={(event) => setSortOrder(event.target.value as SortOrder)}
              aria-label="Sort order"
            >
              <option value="asc">Ascending</option>
              <option value="desc">Descending</option>
            </select>
            <button
              type="button"
              className="button button-secondary"
              onClick={() => setIsSortOpen(false)}
            >
              Close
            </button>
          </div>
        </section>
      ) : null}

      <section className="frame controls fade-in-delay">
        <div className="crumbs">
          {breadcrumbs.map((crumb, index) => (
            <button
              key={`${crumb.id ?? "root"}-${index}`}
              type="button"
              onClick={() => onNavigateToCrumb(index)}
              className="crumb"
            >
              {crumb.name}
            </button>
          ))}
        </div>

        <div className="control-grid">
          <button
            type="button"
            className="button button-primary wide"
            onClick={() => {
              setMessage(null);
              setIsUploadDialogOpen(true);
            }}
            disabled={uploading}
          >
            {uploading ? "Uploading..." : "Upload"}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            onChange={(event) => {
              const file = event.target.files?.[0] ?? null;
              event.currentTarget.value = "";
              void onFileSelected(file);
            }}
            disabled={uploading}
          />
          <input
            ref={folderInputRef}
            type="file"
            className="hidden"
            onChange={(event) => {
              const selected = Array.from(event.target.files ?? []).map((file) => ({
                file,
                relativePath:
                  (file as File & { webkitRelativePath?: string }).webkitRelativePath ||
                  file.name,
              }));
              event.currentTarget.value = "";
              void onFolderSelected(selected);
            }}
            disabled={uploading}
          />

          <button
            type="button"
            onClick={() => {
              setMessage(null);
              setIsCreateFolderOpen(true);
            }}
            className="button button-secondary medium"
          >
            Create folder
          </button>
        </div>

        {message ? <p className="message">{message}</p> : null}
        {uploadTotal > 0 ? (
          <div className="upload-progress" aria-live="polite">
            <p className="subtitle" style={{ marginTop: 0 }}>
              Upload progress: {uploadCompleted}/{uploadTotal} files ({uploadProgressPercent}%)
            </p>
            <div className="progress-track" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={uploadProgressPercent}>
              <div
                className="progress-fill"
                style={{ width: `${uploadProgressPercent}%` }}
              />
            </div>
          </div>
        ) : null}
      </section>

      {breadcrumbs.length > 1 ? (
        <div style={{ display: "flex", justifyContent: "flex-start", paddingInline: "0.1rem" }}>
          <button
            type="button"
            onClick={() => onNavigateToCrumb(breadcrumbs.length - 2)}
            className="button button-secondary"
          >
            Back
          </button>
        </div>
      ) : null}

      <section className="frame table-wrap">
        <table className="drive-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Type</th>
              <th>Size (KB)</th>
              <th>Uploaded</th>
              <th style={{ textAlign: "right" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 ? (
              <tr>
                <td colSpan={5} style={{ color: "var(--text-soft)" }}>
                  No items here.
                </td>
              </tr>
            ) : (
              sortedItems.map((item) => (
                <Fragment key={item.fileId}>
                  <tr className="item-main-row">
                  <td>
                    {item.name}
                    {isFolder(item) ? <span className="badge" style={{ marginLeft: "0.5rem" }}>DIR</span> : null}
                  </td>
                  <td style={{ color: "var(--text-soft)" }}>
                    {isFolder(item) ? "Folder" : item.mimeType ?? "File"}
                  </td>
                  <td style={{ color: "var(--text-soft)", fontFamily: "var(--font-mono), monospace" }}>
                    {isFolder(item) ? "-" : ((item.size ?? 0) / 1024).toFixed(2)}
                  </td>
                  <td style={{ color: "var(--text-soft)" }}>
                    {new Date(item.createdAt).toLocaleString()}
                  </td>
                  <td className="desktop-actions-cell">
                    <div className="actions" style={{ justifyContent: "flex-end" }}>
                      {!isFolder(item) ? (
                        <button
                          type="button"
                          className="button button-secondary"
                          onClick={() => void onPreview(item.fileId)}
                        >
                          Preview
                        </button>
                      ) : null}
                      {isFolder(item) ? (
                        <button
                          type="button"
                          className="button button-secondary"
                          onClick={() => void onOpenFolder(item)}
                        >
                          Open
                        </button>
                      ) : null}
                      <button
                        type="button"
                        className="button button-secondary action-trigger"
                        onClick={(event) => {
                          const rect = event.currentTarget.getBoundingClientRect();
                          const menuWidth = ACTION_MENU_WIDTH;
                          const padding = 12;
                          const calculatedLeft = Math.min(
                            Math.max(padding, rect.right - menuWidth),
                            window.innerWidth - menuWidth - padding,
                          );
                          const calculatedTop = Math.min(
                            rect.bottom + 8,
                            window.innerHeight - 16,
                          );

                          setActionMenuItem(item);
                          setActionMenuPosition({
                            top: calculatedTop,
                            left: calculatedLeft,
                          });
                        }}
                      >
                        Actions
                      </button>
                    </div>
                  </td>
                  </tr>
                  <tr className="mobile-item-actions-row">
                    <td colSpan={5}>
                      <div className="actions mobile-item-actions">
                        {!isFolder(item) ? (
                          <button
                            type="button"
                            className="button button-secondary"
                            onClick={() => void onPreview(item.fileId)}
                          >
                            Preview
                          </button>
                        ) : null}
                        {isFolder(item) ? (
                          <button
                            type="button"
                            className="button button-secondary"
                            onClick={() => void onOpenFolder(item)}
                          >
                            Open
                          </button>
                        ) : null}
                        <button
                          type="button"
                          className="button button-secondary action-trigger"
                          onClick={(event) => {
                            const rect = event.currentTarget.getBoundingClientRect();
                            const menuWidth = ACTION_MENU_WIDTH;
                            const padding = 12;
                            const calculatedLeft = Math.min(
                              Math.max(padding, rect.right - menuWidth),
                              window.innerWidth - menuWidth - padding,
                            );
                            const calculatedTop = Math.min(
                              rect.bottom + 8,
                              window.innerHeight - 16,
                            );

                            setActionMenuItem(item);
                            setActionMenuPosition({
                              top: calculatedTop,
                              left: calculatedLeft,
                            });
                          }}
                        >
                          Actions
                        </button>
                      </div>
                    </td>
                  </tr>
                </Fragment>
              ))
            )}
          </tbody>
        </table>
      </section>

      {actionMenuItem && actionMenuPosition ? (
        <section
          className="floating-action-menu"
          role="dialog"
          aria-modal="false"
          aria-labelledby="item-actions-title"
          style={{
            top: `${actionMenuPosition.top}px`,
            left: `${actionMenuPosition.left}px`,
          }}
        >
          <div className="floating-action-panel">
            <h2 id="item-actions-title" className="title floating-action-title" style={{ fontSize: "0.96rem" }}>
              {actionMenuItem.name}
            </h2>
            <div style={{ display: "grid", gap: "0.35rem" }}>
              {isFolder(actionMenuItem) ? (
                <>
                  <button
                    className="button button-secondary"
                    type="button"
                    onClick={() => {
                      setActionMenuItem(null);
                      setActionMenuPosition(null);
                      void onStartMove(actionMenuItem);
                    }}
                  >
                    Move
                  </button>
                </>
              ) : (
                <>
                  <button
                    className="button button-secondary"
                    type="button"
                    onClick={() => {
                      setActionMenuItem(null);
                      setActionMenuPosition(null);
                      void onViewVersions(actionMenuItem);
                    }}
                  >
                    Versions
                  </button>
                  <button
                    className="button button-secondary"
                    type="button"
                    onClick={() => {
                      setActionMenuItem(null);
                      setActionMenuPosition(null);
                      void onDownload(actionMenuItem.fileId);
                    }}
                  >
                    Download
                  </button>
                  <button
                    className="button button-secondary"
                    type="button"
                    onClick={() => {
                      setActionMenuItem(null);
                      setActionMenuPosition(null);
                      void onStartMove(actionMenuItem);
                    }}
                  >
                    Move
                  </button>
                </>
              )}
              <button
                className="button button-danger"
                type="button"
                onClick={() => {
                  setActionMenuItem(null);
                  setActionMenuPosition(null);
                  onRequestDelete(actionMenuItem);
                }}
              >
                Delete
              </button>
            </div>
            <div className="modal-actions" style={{ marginTop: "0.1rem" }}>
              <button
                type="button"
                className="button button-secondary"
                onClick={() => {
                  setActionMenuItem(null);
                  setActionMenuPosition(null);
                }}
              >
                Close
              </button>
            </div>
          </div>
        </section>
      ) : null}

      {selectedVersionsFile ? (
        <section
          className="modal-overlay"
          role="dialog"
          aria-modal="true"
          aria-labelledby="versions-dialog-title"
        >
          <div className="modal-panel">
            <h2 id="versions-dialog-title" className="title" style={{ fontSize: "1.05rem" }}>
              Version history: {selectedVersionsFile.name}
            </h2>
            <div style={{ display: "grid", gap: "0.5rem" }}>
              {versions.map((version) => (
                <div
                  key={version.versionId}
                  className="version-row"
                >
                  <div style={{ fontSize: "0.82rem" }}>
                    <p className="font-medium">{version.versionId}</p>
                    <p style={{ color: "var(--text-soft)" }}>
                      {new Date(version.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => void onRestoreVersion(version.versionId)}
                    className="button button-secondary"
                  >
                    Restore
                  </button>
                </div>
              ))}
            </div>
            <div className="modal-actions">
              <button
                type="button"
                onClick={() => {
                  setSelectedVersionsFile(null);
                  setVersions([]);
                }}
                className="button button-secondary"
              >
                Close
              </button>
            </div>
          </div>
        </section>
      ) : null}

      {isUploadDialogOpen ? (
        <section
          className="modal-overlay"
          role="dialog"
          aria-modal="true"
          aria-labelledby="upload-dialog-title"
        >
          <div className="modal-panel">
            <h2 id="upload-dialog-title" className="title" style={{ fontSize: "1.05rem" }}>
              Upload
            </h2>
            <p className="subtitle" style={{ marginTop: "0.2rem" }}>
              Choose what you want to upload.
            </p>
            <div className="modal-actions" style={{ justifyContent: "flex-start" }}>
              <button
                type="button"
                className="button button-primary"
                onClick={() => {
                  setIsUploadDialogOpen(false);
                  fileInputRef.current?.click();
                }}
                disabled={uploading}
              >
                Upload file
              </button>
              <button
                type="button"
                className="button button-primary"
                onClick={() => {
                  setIsUploadDialogOpen(false);
                  void openFolderPicker();
                }}
                disabled={uploading}
              >
                Upload folder
              </button>
              <button
                type="button"
                className="button button-secondary"
                onClick={() => setIsUploadDialogOpen(false)}
                disabled={uploading}
              >
                Cancel
              </button>
            </div>
          </div>
        </section>
      ) : null}

      {movingItem ? (
        <section
          className="modal-overlay"
          role="dialog"
          aria-modal="true"
          aria-labelledby="move-dialog-title"
        >
          <div className="modal-panel">
            <h2 id="move-dialog-title" className="title" style={{ fontSize: "1.05rem" }}>
              Move: {movingItem.name}
            </h2>
            <div style={{ display: "grid", gap: "0.6rem" }}>
              <label htmlFor="move-target" style={{ color: "var(--text-soft)", fontSize: "0.9rem" }}>
                Target folder
              </label>
              <select
                id="move-target"
                className="input"
                value={moveTargetParentId}
                onChange={(event) => setMoveTargetParentId(event.target.value)}
                disabled={moving}
              >
                <option value="ROOT">My Drive (root)</option>
                {folderOptions.map((folder) => (
                  <option key={folder.fileId} value={folder.fileId}>
                    {folder.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="modal-actions">
              <button
                type="button"
                onClick={() => {
                  setMovingItem(null);
                  setFolderOptions([]);
                  setMoveTargetParentId("ROOT");
                }}
                className="button button-secondary"
                disabled={moving}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void onConfirmMove()}
                className="button button-primary"
                disabled={moving}
              >
                {moving ? "Moving..." : "Confirm move"}
              </button>
            </div>
          </div>
        </section>
      ) : null}

      {isCreateFolderOpen ? (
        <section
          className="modal-overlay"
          role="dialog"
          aria-modal="true"
          aria-labelledby="create-folder-title"
        >
          <div className="modal-panel">
            <h2 id="create-folder-title" className="title" style={{ fontSize: "1.05rem" }}>
              Create folder
            </h2>
            <p className="subtitle" style={{ marginTop: "0.2rem" }}>
              Enter a name for your new folder.
            </p>
            <input
              type="text"
              value={folderName}
              onChange={(event) => setFolderName(event.target.value)}
              placeholder="Folder name"
              className="input"
              autoFocus
              disabled={creatingFolder}
            />
            <div className="modal-actions">
              <button
                type="button"
                onClick={() => {
                  setIsCreateFolderOpen(false);
                  setFolderName("");
                }}
                className="button button-secondary"
                disabled={creatingFolder}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void onCreateFolder()}
                disabled={creatingFolder}
                className="button button-primary"
              >
                {creatingFolder ? "Creating..." : "Create new folder"}
              </button>
            </div>
          </div>
        </section>
      ) : null}

      {deleteCandidate ? (
        <section
          className="modal-overlay"
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-confirm-title"
        >
          <div className="modal-panel">
            <h2 id="delete-confirm-title" className="title" style={{ fontSize: "1.05rem" }}>
              Confirm delete
            </h2>
            <p className="subtitle" style={{ marginTop: "0.2rem" }}>
              Delete {isFolder(deleteCandidate) ? "folder" : "file"} &quot;{deleteCandidate.name}&quot;? This action cannot be undone.
            </p>
            <div className="modal-actions">
              <button
                type="button"
                onClick={() => setDeleteCandidate(null)}
                className="button button-secondary"
                disabled={deleting}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void onConfirmDelete()}
                className="button button-danger"
                disabled={deleting}
              >
                {deleting ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </section>
      ) : null}
    </main>
  );
}
