"use client";

import { isFolder, type DriveItem } from "@/lib/drive";
import Link from "next/link";
import { signIn, signOut, useSession } from "next-auth/react";
import { Fragment, useCallback, useEffect, useState } from "react";

export function BinClient() {
  const { data: session, status } = useSession();
  const [items, setItems] = useState<DriveItem[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [restoringId, setRestoringId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [clearing, setClearing] = useState(false);
  const [isClearDialogOpen, setIsClearDialogOpen] = useState(false);

  const isAuthenticated = status === "authenticated" && !!session?.user?.id;

  const refreshBin = useCallback(async () => {
    if (!isAuthenticated) {
      setItems([]);
      return;
    }

    const res = await fetch("/api/bin", { cache: "no-store" });

    if (!res.ok) {
      setMessage("Could not load bin items.");
      return;
    }

    const payload = (await res.json()) as { items: DriveItem[] };
    setItems(payload.items ?? []);
  }, [isAuthenticated]);

  useEffect(() => {
    void refreshBin();
  }, [refreshBin]);

  useEffect(() => {
    if (!message) {
      return;
    }

    const timer = window.setTimeout(() => {
      setMessage(null);
    }, 10000);

    return () => {
      window.clearTimeout(timer);
    };
  }, [message]);

  async function onSignIn() {
    await signIn("cognito");
  }

  async function onSignOut() {
    await signOut({ redirect: false });
    window.location.href = "/api/auth/cognito-signout";
  }

  async function onRestore(item: DriveItem) {
    setRestoringId(item.fileId);
    setMessage(null);

    const res = await fetch("/api/bin/restore", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ fileId: item.fileId }),
    });

    if (!res.ok) {
      const payload = (await res.json().catch(() => null)) as
        | { error?: string }
        | null;
      setMessage(payload?.error ?? "Could not restore item.");
      setRestoringId(null);
      return;
    }

    setRestoringId(null);
    setMessage(`Restored ${item.name}.`);
    await refreshBin();
  }

  async function onClearAll() {
    setClearing(true);
    setMessage(null);

    const res = await fetch("/api/bin", {
      method: "DELETE",
    });

    if (!res.ok) {
      const payload = (await res.json().catch(() => null)) as
        | { error?: string }
        | null;
      setMessage(payload?.error ?? "Could not clear bin.");
      setClearing(false);
      return;
    }

    setClearing(false);
    setIsClearDialogOpen(false);
    setMessage("Bin cleared.");
    await refreshBin();
  }

  async function onPermanentDelete(item: DriveItem) {
    const confirmed = window.confirm(
      `Permanently delete ${item.name}? This action cannot be undone.`,
    );

    if (!confirmed) {
      return;
    }

    setDeletingId(item.fileId);
    setMessage(null);

    const res = await fetch(`/api/bin/${item.fileId}`, {
      method: "DELETE",
    });

    if (!res.ok) {
      const payload = (await res.json().catch(() => null)) as
        | { error?: string }
        | null;
      setMessage(payload?.error ?? "Could not permanently delete item.");
      setDeletingId(null);
      return;
    }

    setDeletingId(null);
    setMessage(`Permanently deleted ${item.name}.`);
    await refreshBin();
  }

  if (status === "loading") {
    return (
      <main className="drive-shell">
        <section className="frame auth-card fade-in">
          <h1 className="title">Preparing your bin</h1>
          <p className="subtitle">Checking your session with Cognito...</p>
        </section>
      </main>
    );
  }

  if (!isAuthenticated) {
    return (
      <main className="drive-shell">
        <section className="frame auth-card fade-in">
          <h1 className="title">Sign in to open your bin</h1>
          <p className="subtitle">
            Recently deleted files and folders are available after sign in.
          </p>
          <button
            type="button"
            onClick={() => void onSignIn()}
            className="button button-primary"
            style={{ marginTop: "1rem" }}
          >
            Sign in with Cognito
          </button>
        </section>
      </main>
    );
  }

  return (
    <main className="drive-shell fade-in">
      <header className="frame glass top-bar">
        <div>
          <h1 className="title">Recently Deleted</h1>
          <p className="subtitle">
            {session.user.email ?? "Signed in user"} • {items.length} items in bin
          </p>
        </div>
        <div style={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
          <Link href="/" className="button button-secondary">
            Back to Drive
          </Link>
          <button
            type="button"
            className="button button-danger"
            onClick={() => setIsClearDialogOpen(true)}
            disabled={items.length === 0 || clearing}
          >
            Permanently delete all
          </button>
          <button
            type="button"
            onClick={() => void onSignOut()}
            className="button button-secondary"
          >
            Sign out
          </button>
        </div>
      </header>

      <section className="frame controls fade-in-delay">
        {message ? <p className="message">{message}</p> : null}
      </section>

      <section className="frame table-wrap">
        <table className="drive-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Type</th>
              <th>Deleted</th>
              <th style={{ textAlign: "right" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 ? (
              <tr>
                <td colSpan={4} style={{ color: "var(--text-soft)" }}>
                  Bin is empty.
                </td>
              </tr>
            ) : (
              items.map((item) => (
                <Fragment key={item.fileId}>
                  <tr className="item-main-row">
                  <td>{item.name}</td>
                  <td style={{ color: "var(--text-soft)" }}>
                    {isFolder(item) ? "Folder" : item.mimeType ?? "File"}
                  </td>
                  <td style={{ color: "var(--text-soft)" }}>
                    {item.deletedAt ? new Date(item.deletedAt).toLocaleString() : "-"}
                  </td>
                  <td className="desktop-actions-cell">
                    <div className="actions">
                      <button
                        type="button"
                        className="button button-secondary"
                        onClick={() => void onRestore(item)}
                        disabled={
                          restoringId === item.fileId ||
                          deletingId === item.fileId ||
                          clearing
                        }
                      >
                        {restoringId === item.fileId ? "Restoring..." : "Restore"}
                      </button>
                      <button
                        type="button"
                        className="button button-danger"
                        onClick={() => void onPermanentDelete(item)}
                        disabled={
                          restoringId === item.fileId ||
                          deletingId === item.fileId ||
                          clearing
                        }
                      >
                        {deletingId === item.fileId
                          ? "Deleting..."
                          : "Permanently delete"}
                      </button>
                    </div>
                  </td>
                  </tr>
                  <tr className="mobile-item-actions-row">
                    <td colSpan={4}>
                      <div className="actions mobile-item-actions">
                        <button
                          type="button"
                          className="button button-secondary"
                          onClick={() => void onRestore(item)}
                          disabled={
                            restoringId === item.fileId ||
                            deletingId === item.fileId ||
                            clearing
                          }
                        >
                          {restoringId === item.fileId ? "Restoring..." : "Restore"}
                        </button>
                        <button
                          type="button"
                          className="button button-danger"
                          onClick={() => void onPermanentDelete(item)}
                          disabled={
                            restoringId === item.fileId ||
                            deletingId === item.fileId ||
                            clearing
                          }
                        >
                          {deletingId === item.fileId
                            ? "Deleting..."
                            : "Permanently delete"}
                        </button>
                      </div>
                    </td>
                  </tr>
                </Fragment>
              ))
            )}
          </tbody>
        </table>
      </section>

      {isClearDialogOpen ? (
        <section
          className="modal-overlay"
          role="dialog"
          aria-modal="true"
          aria-labelledby="clear-bin-title"
        >
          <div className="modal-panel">
            <h2 id="clear-bin-title" className="title" style={{ fontSize: "1.05rem" }}>
              Clear bin
            </h2>
            <p className="subtitle" style={{ marginTop: "0.2rem" }}>
              Permanently delete all items in bin? This cannot be undone.
            </p>
            <div className="modal-actions">
              <button
                type="button"
                onClick={() => setIsClearDialogOpen(false)}
                className="button button-secondary"
                disabled={clearing}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void onClearAll()}
                className="button button-danger"
                disabled={clearing}
              >
                {clearing ? "Clearing..." : "Clear all"}
              </button>
            </div>
          </div>
        </section>
      ) : null}
    </main>
  );
}
