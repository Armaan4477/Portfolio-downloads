import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const cognitoDomain = process.env.AUTH_COGNITO_DOMAIN;
  const clientId = process.env.AUTH_COGNITO_ID;
  const nextAuthUrl = process.env.NEXTAUTH_URL;

  if (!cognitoDomain || !clientId || !nextAuthUrl) {
    const fallback = new URL("/", request.url);
    return NextResponse.redirect(fallback);
  }

  const base = cognitoDomain.startsWith("http")
    ? cognitoDomain
    : `https://${cognitoDomain}`;

  const logoutUrl = new URL("/logout", base);
  logoutUrl.searchParams.set("client_id", clientId);
  logoutUrl.searchParams.set("logout_uri", nextAuthUrl);

  return NextResponse.redirect(logoutUrl);
}
