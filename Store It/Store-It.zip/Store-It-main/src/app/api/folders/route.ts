import { getAuthSession } from "@/auth";
import { getAwsClients } from "@/lib/aws";
import { isFolder, type DriveItem } from "@/lib/drive";
import { PutCommand } from "@aws-sdk/lib-dynamodb";
import { QueryCommand } from "@aws-sdk/lib-dynamodb";
import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { z } from "zod";

const createFolderSchema = z.object({
  name: z.string().min(1),
  parentId: z.string().min(1).nullable().optional(),
});

export async function GET() {
  const session = await getAuthSession();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { dynamoDocClient, tableName } = getAwsClients();
  const output = await dynamoDocClient.send(
    new QueryCommand({
      TableName: tableName,
      KeyConditionExpression: "userId = :userId",
      ExpressionAttributeValues: {
        ":userId": session.user.id,
      },
    }),
  );

  const folders = ((output.Items as DriveItem[]) ?? [])
    .filter((item) => isFolder(item) && !item.deletedAt)
    .sort((a, b) => a.name.localeCompare(b.name));

  return NextResponse.json({ folders });
}

export async function POST(request: Request) {
  const session = await getAuthSession();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();
  const parsed = createFolderSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }

  const { dynamoDocClient, tableName } = getAwsClients();
  const fileId = randomUUID();
  const createdAt = new Date().toISOString();

  await dynamoDocClient.send(
    new PutCommand({
      TableName: tableName,
      Item: {
        userId: session.user.id,
        fileId,
        entityType: "folder",
        parentId: parsed.data.parentId ?? null,
        name: parsed.data.name,
        createdAt,
      },
      ConditionExpression: "attribute_not_exists(userId) AND attribute_not_exists(fileId)",
    }),
  );

  return NextResponse.json({ fileId });
}
