import { getAuthSession } from "@/auth";
import { getAwsClients } from "@/lib/aws";
import type { DriveItem } from "@/lib/drive";
import { QueryCommand } from "@aws-sdk/lib-dynamodb";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const session = await getAuthSession();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { dynamoDocClient, tableName } = getAwsClients();
  const { searchParams } = new URL(request.url);
  const rawParentId = searchParams.get("parentId");
  const parentId = rawParentId && rawParentId.trim().length > 0 ? rawParentId : null;
  const search = searchParams.get("search")?.trim().toLowerCase() ?? "";

  const output = await dynamoDocClient.send(
    new QueryCommand({
      TableName: tableName,
      KeyConditionExpression: "userId = :userId",
      ExpressionAttributeValues: {
        ":userId": session.user.id,
      },
      ScanIndexForward: false,
    }),
  );

  const items = ((output.Items as DriveItem[]) ?? [])
    .filter((item) => {
      if (item.deletedAt) {
        return false;
      }

      if (search.length > 0) {
        return item.name.toLowerCase().includes(search);
      }
      const normalizedParentId = item.parentId ?? null;
      return normalizedParentId === parentId;
    })
    .sort((a, b) => {
      if ((a.entityType ?? "file") !== (b.entityType ?? "file")) {
        return (a.entityType ?? "file") === "folder" ? -1 : 1;
      }
      return a.name.localeCompare(b.name);
    });

  return NextResponse.json({ items });
}
