import { getAuthSession } from "@/auth";
import { getAwsClients } from "@/lib/aws";
import { type DriveItem, isFolder } from "@/lib/drive";
import { GetCommand, QueryCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { NextResponse } from "next/server";
import { z } from "zod";

const moveSchema = z.object({
  targetParentId: z.string().min(1).nullable(),
});

export async function POST(
  request: Request,
  { params }: { params: Promise<{ fileId: string }> },
) {
  const session = await getAuthSession();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { fileId } = await params;
  const body = await request.json();
  const parsed = moveSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }

  const { dynamoDocClient, tableName } = getAwsClients();

  const itemOutput = await dynamoDocClient.send(
    new GetCommand({
      TableName: tableName,
      Key: { userId: session.user.id, fileId },
    }),
  );

  const item = itemOutput.Item as DriveItem | undefined;

  if (!item || item.deletedAt) {
    return NextResponse.json({ error: "Item not found" }, { status: 404 });
  }

  const targetParentId = parsed.data.targetParentId;

  if (targetParentId === fileId) {
    return NextResponse.json(
      { error: "Cannot move item into itself" },
      { status: 400 },
    );
  }

  if (targetParentId) {
    const targetOutput = await dynamoDocClient.send(
      new GetCommand({
        TableName: tableName,
        Key: { userId: session.user.id, fileId: targetParentId },
      }),
    );

    const target = targetOutput.Item as DriveItem | undefined;
    if (!target || target.deletedAt || !isFolder(target)) {
      return NextResponse.json(
        { error: "Target folder not found" },
        { status: 404 },
      );
    }

    if (isFolder(item)) {
      const allItemsOutput = await dynamoDocClient.send(
        new QueryCommand({
          TableName: tableName,
          KeyConditionExpression: "userId = :userId",
          ExpressionAttributeValues: {
            ":userId": session.user.id,
          },
        }),
      );

      const allItems = (allItemsOutput.Items as DriveItem[]) ?? [];
      const byParent = new Map<string, DriveItem[]>();
      for (const current of allItems) {
        const parent = current.parentId ?? "ROOT";
        const list = byParent.get(parent) ?? [];
        list.push(current);
        byParent.set(parent, list);
      }

      const stack = [fileId];
      while (stack.length > 0) {
        const current = stack.pop()!;
        if (current === targetParentId) {
          return NextResponse.json(
            { error: "Cannot move folder into its descendant" },
            { status: 400 },
          );
        }
        const children = byParent.get(current) ?? [];
        for (const child of children) {
          if (isFolder(child)) {
            stack.push(child.fileId);
          }
        }
      }
    }
  }

  await dynamoDocClient.send(
    new UpdateCommand({
      TableName: tableName,
      Key: { userId: session.user.id, fileId },
      UpdateExpression: "SET parentId = :parentId",
      ExpressionAttributeValues: {
        ":parentId": targetParentId,
      },
    }),
  );

  return NextResponse.json({ success: true });
}
