import { getAuthSession } from "@/auth";
import { getAwsClients } from "@/lib/aws";
import { GetObjectCommand } from "@aws-sdk/client-s3";
import { GetCommand } from "@aws-sdk/lib-dynamodb";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { NextResponse } from "next/server";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ fileId: string }> },
) {
  const session = await getAuthSession();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { s3Client, dynamoDocClient, bucketName, tableName } = getAwsClients();

  const { fileId } = await params;

  const output = await dynamoDocClient.send(
    new GetCommand({
      TableName: tableName,
      Key: {
        userId: session.user.id,
        fileId,
      },
    }),
  );

  if (
    !output.Item ||
    output.Item.deletedAt ||
    output.Item.entityType === "folder" ||
    !output.Item.objectKey
  ) {
    return NextResponse.json({ error: "File not found" }, { status: 404 });
  }

  const command = new GetObjectCommand({
    Bucket: bucketName,
    Key: output.Item.objectKey,
    ResponseContentDisposition: `attachment; filename=\"${output.Item.name}\"`,
  });

  const downloadUrl = await getSignedUrl(s3Client, command, {
    expiresIn: 300,
  });

  return NextResponse.json({ downloadUrl });
}
