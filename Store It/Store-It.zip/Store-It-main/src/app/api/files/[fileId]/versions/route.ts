import { getAuthSession } from "@/auth";
import { getAwsClients } from "@/lib/aws";
import { type FileVersion } from "@/lib/drive";
import { GetCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { NextResponse } from "next/server";
import { z } from "zod";

const restoreSchema = z.object({
  versionId: z.string().min(1),
});

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ fileId: string }> },
) {
  const session = await getAuthSession();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { fileId } = await params;
  const { dynamoDocClient, tableName } = getAwsClients();

  const item = await dynamoDocClient.send(
    new GetCommand({
      TableName: tableName,
      Key: { userId: session.user.id, fileId },
    }),
  );

  if (!item.Item || item.Item.deletedAt || item.Item.entityType === "folder") {
    return NextResponse.json({ error: "File not found" }, { status: 404 });
  }

  return NextResponse.json({
    versions: ((item.Item.versions as FileVersion[]) ?? []).toReversed(),
    latestVersion: item.Item.latestVersion ?? 1,
  });
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ fileId: string }> },
) {
  const session = await getAuthSession();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();
  const parsed = restoreSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }

  const { fileId } = await params;
  const { dynamoDocClient, tableName } = getAwsClients();

  const item = await dynamoDocClient.send(
    new GetCommand({
      TableName: tableName,
      Key: { userId: session.user.id, fileId },
    }),
  );

  if (!item.Item || item.Item.deletedAt || item.Item.entityType === "folder") {
    return NextResponse.json({ error: "File not found" }, { status: 404 });
  }

  const versions = (item.Item.versions as FileVersion[]) ?? [];
  const chosen = versions.find((version) => version.versionId === parsed.data.versionId);

  if (!chosen) {
    return NextResponse.json({ error: "Version not found" }, { status: 404 });
  }

  await dynamoDocClient.send(
    new UpdateCommand({
      TableName: tableName,
      Key: { userId: session.user.id, fileId },
      UpdateExpression: "SET objectKey = :objectKey, mimeType = :mimeType, size = :size",
      ExpressionAttributeValues: {
        ":objectKey": chosen.objectKey,
        ":mimeType": chosen.mimeType,
        ":size": chosen.size,
      },
    }),
  );

  return NextResponse.json({ success: true });
}
