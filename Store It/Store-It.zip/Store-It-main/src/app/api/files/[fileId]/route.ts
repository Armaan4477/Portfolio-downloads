import { getAuthSession } from "@/auth";
import { getAwsClients } from "@/lib/aws";
import { isFolder, type DriveItem } from "@/lib/drive";
import { GetCommand, QueryCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { NextResponse } from "next/server";

function collectDescendantIds(rootId: string, allItems: DriveItem[]) {
  const byParent = new Map<string, DriveItem[]>();

  for (const item of allItems) {
    const parentKey = item.parentId ?? "ROOT";
    const list = byParent.get(parentKey) ?? [];
    list.push(item);
    byParent.set(parentKey, list);
  }

  const descendants: string[] = [];
  const stack = [rootId];

  while (stack.length > 0) {
    const current = stack.pop()!;
    const children = byParent.get(current) ?? [];

    for (const child of children) {
      descendants.push(child.fileId);
      if (isFolder(child)) {
        stack.push(child.fileId);
      }
    }
  }

  return descendants;
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ fileId: string }> },
) {
  const session = await getAuthSession();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { dynamoDocClient, tableName } = getAwsClients();

  const { fileId } = await params;

  const existing = await dynamoDocClient.send(
    new GetCommand({
      TableName: tableName,
      Key: {
        userId: session.user.id,
        fileId,
      },
    }),
  );

  if (!existing.Item || existing.Item.deletedAt) {
    return NextResponse.json({ error: "File not found" }, { status: 404 });
  }

  const existingItem = existing.Item as DriveItem;

  const allItemsOutput = await dynamoDocClient.send(
    new QueryCommand({
      TableName: tableName,
      KeyConditionExpression: "userId = :userId",
      ExpressionAttributeValues: {
        ":userId": session.user.id,
      },
    }),
  );

  const allItems = (allItemsOutput.Items as DriveItem[]) ?? [];

  const idsToDelete = isFolder(existingItem)
    ? [fileId, ...collectDescendantIds(fileId, allItems)]
    : [fileId];

  const deletedAt = new Date().toISOString();

  for (const id of idsToDelete) {
    await dynamoDocClient.send(
      new UpdateCommand({
        TableName: tableName,
        Key: {
          userId: session.user.id,
          fileId: id,
        },
        UpdateExpression: "SET deletedAt = :deletedAt",
        ExpressionAttributeValues: {
          ":deletedAt": deletedAt,
        },
      }),
    );
  }

  return NextResponse.json({ success: true, deletedCount: idsToDelete.length });
}
