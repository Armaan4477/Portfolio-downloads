import { getAuthSession } from "@/auth";
import { getAwsClients } from "@/lib/aws";
import { GetObjectCommand } from "@aws-sdk/client-s3";
import { GetCommand } from "@aws-sdk/lib-dynamodb";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { NextResponse } from "next/server";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ fileId: string }> },
) {
  const session = await getAuthSession();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { s3Client, dynamoDocClient, bucketName, tableName } = getAwsClients();
  const { fileId } = await params;

  const item = await dynamoDocClient.send(
    new GetCommand({
      TableName: tableName,
      Key: {
        userId: session.user.id,
        fileId,
      },
    }),
  );

  if (
    !item.Item ||
    item.Item.deletedAt ||
    item.Item.entityType === "folder" ||
    !item.Item.objectKey
  ) {
    return NextResponse.json({ error: "File not found" }, { status: 404 });
  }

  const mimeType = String(item.Item.mimeType ?? "application/octet-stream");

  const command = new GetObjectCommand({
    Bucket: bucketName,
    Key: item.Item.objectKey,
    ResponseContentDisposition: `inline; filename=\"${item.Item.name}\"`,
    ResponseContentType: mimeType,
  });

  const previewUrl = await getSignedUrl(s3Client, command, { expiresIn: 300 });
  return NextResponse.json({ previewUrl });
}
