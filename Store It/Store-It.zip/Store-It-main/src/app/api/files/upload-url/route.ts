import { getAuthSession } from "@/auth";
import { getAwsClients } from "@/lib/aws";
import { isFile, toSafeFileName, type DriveItem, type FileVersion } from "@/lib/drive";
import { PutObjectCommand } from "@aws-sdk/client-s3";
import { PutCommand, QueryCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { z } from "zod";

const uploadSchema = z.object({
  name: z.string().min(1),
  mimeType: z.string().min(1),
  size: z.number().int().positive(),
  parentId: z.string().min(1).nullable().optional(),
});

export async function POST(request: Request) {
  const session = await getAuthSession();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { s3Client, dynamoDocClient, bucketName, tableName } = getAwsClients();

  const body = await request.json();
  const parsed = uploadSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }

  const { name, mimeType, size } = parsed.data;
  const parentId = parsed.data.parentId ?? null;
  const createdAt = new Date().toISOString();
  const thumbnailStatus = mimeType.startsWith("image/") ? "PENDING" : "READY";

  const existingList = await dynamoDocClient.send(
    new QueryCommand({
      TableName: tableName,
      KeyConditionExpression: "userId = :userId",
      ExpressionAttributeValues: {
        ":userId": session.user.id,
      },
    }),
  );

  const existingFile = ((existingList.Items as DriveItem[]) ?? []).find(
    (item) =>
      isFile(item) &&
      !item.deletedAt &&
      item.name === name &&
      (item.parentId ?? null) === parentId,
  );

  const fileId = existingFile?.fileId ?? randomUUID();
  const nextVersion = (existingFile?.latestVersion ?? 0) + 1;
  const versionId = `v${nextVersion}`;
  const objectKey = `${session.user.id}/${fileId}/${versionId}-${toSafeFileName(name)}`;

  const putObject = new PutObjectCommand({
    Bucket: bucketName,
    Key: objectKey,
    ContentType: mimeType,
  });

  const uploadUrl = await getSignedUrl(s3Client, putObject, {
    expiresIn: 300,
  });

  const newVersion: FileVersion = {
    versionId,
    objectKey,
    size,
    mimeType,
    createdAt,
  };

  if (!existingFile) {
    await dynamoDocClient.send(
      new PutCommand({
        TableName: tableName,
        Item: {
          userId: session.user.id,
          fileId,
          entityType: "file",
          parentId,
          name,
          mimeType,
          size,
          objectKey,
          latestVersion: 1,
          versions: [newVersion],
          thumbnailStatus,
          createdAt,
        },
      }),
    );
  } else {
    const previousVersions = existingFile.versions ?? [];
    await dynamoDocClient.send(
      new UpdateCommand({
        TableName: tableName,
        Key: {
          userId: session.user.id,
          fileId,
        },
        UpdateExpression:
          "SET mimeType = :mimeType, size = :size, objectKey = :objectKey, latestVersion = :latestVersion, versions = :versions, thumbnailStatus = :thumbnailStatus",
        ExpressionAttributeValues: {
          ":mimeType": mimeType,
          ":size": size,
          ":objectKey": objectKey,
          ":latestVersion": nextVersion,
          ":versions": [...previousVersions, newVersion],
          ":thumbnailStatus": thumbnailStatus,
        },
      }),
    );
  }

  return NextResponse.json({
    fileId,
    versionId,
    uploadUrl,
  });
}
