import { DriveClient } from "@/components/drive-client";

export default function Home() {
  return <DriveClient />;
}
