import { GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import type { S3Event } from "aws-lambda";
import { Jimp } from "jimp";

const s3 = new S3Client({});
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));

const tableName = process.env.TABLE_NAME;
const bucketName = process.env.BUCKET_NAME;

async function streamToBuffer(stream: NodeJS.ReadableStream) {
  const chunks: Buffer[] = [];
  for await (const chunk of stream) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }
  return Buffer.concat(chunks);
}

function parseKey(key: string) {
  const decoded = decodeURIComponent(key.replace(/\+/g, " "));
  const [userId, fileId] = decoded.split("/");
  return { decoded, userId, fileId };
}

export const handler = async (event: S3Event) => {
  if (!tableName || !bucketName) {
    throw new Error("Missing TABLE_NAME or BUCKET_NAME environment variables");
  }

  for (const record of event.Records) {
    const rawKey = record.s3.object.key;
    const { decoded, userId, fileId } = parseKey(rawKey);

    if (!userId || !fileId || decoded.includes("/thumbs/")) {
      continue;
    }

    const fileObject = await s3.send(
      new GetObjectCommand({
        Bucket: bucketName,
        Key: decoded,
      }),
    );

    const contentType = fileObject.ContentType ?? "";

    if (!contentType.startsWith("image/")) {
      continue;
    }

    if (!fileObject.Body) {
      continue;
    }

    const source = await streamToBuffer(fileObject.Body as NodeJS.ReadableStream);

    const image = await Jimp.read(source);
    image.scaleToFit({ w: 320, h: 320 });
    const thumbnailBuffer = await image.getBuffer("image/jpeg");

    const thumbKey = `${userId}/${fileId}/thumbs/latest.jpg`;

    await s3.send(
      new PutObjectCommand({
        Bucket: bucketName,
        Key: thumbKey,
        Body: thumbnailBuffer,
        ContentType: "image/jpeg",
      }),
    );

    const userItems = await ddb.send(
      new QueryCommand({
        TableName: tableName,
        KeyConditionExpression: "userId = :userId",
        ExpressionAttributeValues: {
          ":userId": userId,
        },
      }),
    );

    const target = (userItems.Items ?? []).find(
      (item) =>
        item.fileId === fileId &&
        item.entityType !== "folder" &&
        ((item.objectKey as string | undefined) ?? "") === decoded,
    );

    if (!target) {
      continue;
    }

    await ddb.send(
      new UpdateCommand({
        TableName: tableName,
        Key: {
          userId,
          fileId,
        },
        UpdateExpression: "SET thumbnailKey = :thumbnailKey, thumbnailStatus = :status",
        ExpressionAttributeValues: {
          ":thumbnailKey": thumbKey,
          ":status": "READY",
        },
      }),
    );
  }
};
