# Store It

Cloud file workspace built with Next.js and AWS.

Store It provides authenticated file storage with folders, version history, soft delete bin, restore flow, and automatic thumbnail generation for images.

## Tech Stack

- Next.js 16 (App Router)
- React 19
- NextAuth + Amazon Cognito (Hosted UI)
- Amazon S3 (binary storage)
- Amazon DynamoDB (file and folder metadata)
- AWS CDK (infrastructure provisioning)
- AWS Lambda + Jimp (image thumbnail generation)

## What You Get

- Cognito sign-in/sign-out with session-based auth
- Upload files to S3 using pre-signed URLs
- Folder creation and nested folder/file browsing
- File and folder move operations
- File version history with version restore
- Preview and download pre-signed URLs
- Soft delete to bin and restore from bin
- Permanent delete for one item or entire bin
- Automatic 320x320 JPEG thumbnails for image uploads

## Architecture

1. User signs in with Cognito through NextAuth.
2. App APIs validate session user ID.
3. Metadata is stored in DynamoDB (`userId` + `fileId`).
4. File uploads are direct browser-to-S3 via pre-signed PUT URL.
5. S3 object-created event triggers a thumbnail Lambda.
6. Lambda writes thumbnail status/key back to DynamoDB.

## Project Structure

```text
src/
	app/
		page.tsx                 # Drive UI
		bin/page.tsx             # Bin UI
		api/                     # Route handlers
	components/
		drive-client.tsx         # Main file manager UX
		bin-client.tsx           # Bin UX
	auth.ts                    # NextAuth Cognito config
	lib/
		aws.ts                   # AWS SDK clients
		env.ts                   # Server env parsing/validation
		drive.ts                 # Shared Drive item/version types

infrastructure/
	bin/cdk.ts                 # CDK app entrypoint
	lib/drive-stack.ts         # AWS resources
	lambda/thumbnail-processor.ts
```

## Prerequisites

- Node.js 20+
- npm
- AWS CLI configured (`aws configure`)
- CDK bootstrap complete in your target account/region

## Quick Start

### 1. Install dependencies

```bash
npm install
```

### 2. Bootstrap CDK (first time per account/region)

```bash
npx cdk bootstrap
```

### 3. Deploy infrastructure

```bash
npm run cdk:deploy
```

Capture stack outputs:

- `DriveBucketName`
- `DriveTableName`
- `CognitoUserPoolClientId`
- `CognitoDomain`
- `CognitoIssuer`

### 4. Configure environment

Copy and edit env file:

```bash
cp .env.example .env.local
```

Set these values in `.env.local`:

- `NEXTAUTH_URL` (local: `http://localhost:3000`)
- `NEXTAUTH_SECRET`
- `AUTH_COGNITO_ID` (from `CognitoUserPoolClientId`)
- `AUTH_COGNITO_SECRET` (from Cognito App Client secret)
- `AUTH_COGNITO_ISSUER` (from `CognitoIssuer`)
- `AUTH_COGNITO_DOMAIN` (from `CognitoDomain`)
- `APP_AWS_REGION`
- `APP_S3_BUCKET_NAME` (from `DriveBucketName`)
- `APP_DYNAMODB_FILES_TABLE` (from `DriveTableName`)

Optional local-only credentials:

- `APP_AWS_ACCESS_KEY_ID`
- `APP_AWS_SECRET_ACCESS_KEY`
- `APP_AWS_SESSION_TOKEN`

### 5. Verify Cognito callback/logout URLs

In Cognito App Client, include:

- Callback URL: `http://localhost:3000/api/auth/callback/cognito`
- Logout URL: `http://localhost:3000`

### 6. Start app

```bash
npm run dev
```

Open `http://localhost:3000`.

## Available Scripts

- `npm run dev` - Start Next.js dev server
- `npm run build` - Build production bundle
- `npm run start` - Start production server
- `npm run lint` - Run ESLint
- `npm run cdk:synth` - Synthesize CloudFormation templates
- `npm run cdk:deploy` - Deploy AWS resources from CDK

## API Reference

All routes below require authentication unless noted otherwise.

### Auth

- `GET|POST /api/auth/[...nextauth]`
	- NextAuth handler for Cognito auth flow
	- Public endpoint used by auth framework
- `GET /api/auth/cognito-signout`
	- Redirects to Cognito logout endpoint
	- Public endpoint

### Files

- `GET /api/files?parentId=<id>&search=<term>`
	- Returns current folder items or search results
	- Response: `{ items: DriveItem[] }`
- `POST /api/files/upload-url`
	- Body: `{ name, mimeType, size, parentId? }`
	- Creates/updates file metadata and version entry
	- Response: `{ fileId, versionId, uploadUrl }`
- `DELETE /api/files/:fileId`
	- Soft-deletes file/folder (and descendants for folders)
	- Response: `{ success: true, deletedCount }`
- `POST /api/files/:fileId/move`
	- Body: `{ targetParentId: string | null }`
	- Prevents invalid moves (self/descendant)
	- Response: `{ success: true }`
- `GET /api/files/:fileId/download-url`
	- Response: `{ downloadUrl }` (5-minute signed URL)
- `GET /api/files/:fileId/preview-url`
	- Response: `{ previewUrl }` (5-minute signed URL)
- `GET /api/files/:fileId/versions`
	- Response: `{ versions, latestVersion }`
- `POST /api/files/:fileId/versions`
	- Body: `{ versionId }`
	- Restores selected version as active object
	- Response: `{ success: true }`

### Folders

- `GET /api/folders`
	- Lists all non-deleted folders
	- Response: `{ folders: DriveItem[] }`
- `POST /api/folders`
	- Body: `{ name, parentId? }`
	- Response: `{ fileId }`

### Bin

- `GET /api/bin`
	- Returns root-level deleted items
	- Response: `{ items: DriveItem[] }`
- `POST /api/bin/restore`
	- Body: `{ fileId }`
	- Restores item (and descendants for folders)
	- Response: `{ success: true, restoredCount }`
- `DELETE /api/bin/:fileId`
	- Permanently deletes item and descendants
	- Removes S3 objects and DynamoDB records
	- Response: `{ success: true, deletedCount }`
- `DELETE /api/bin`
	- Permanently empties bin for current user
	- Response: `{ success: true, deletedCount }`

## Data Model (DynamoDB)

Primary key:

- Partition key: `userId`
- Sort key: `fileId`

Main attributes used:

- `entityType`: `file` or `folder`
- `name`
- `parentId`
- `deletedAt` (soft delete marker)
- `mimeType`, `size`, `objectKey`
- `latestVersion`
- `versions[]` with `{ versionId, objectKey, size, mimeType, createdAt }`
- `thumbnailStatus`, `thumbnailKey`
- `createdAt`

## Infrastructure (CDK)

`infrastructure/lib/drive-stack.ts` provisions:

- S3 bucket (`DriveBucket`) with CORS, SSL enforcement, encryption, and object auto-delete on destroy
- DynamoDB table (`DriveFilesTable`) with on-demand billing
- Lambda thumbnail processor (`ThumbnailProcessor`)
- Cognito User Pool + hosted domain + App Client (authorization code flow)

Stack outputs:

- `DriveBucketName`
- `DriveTableName`
- `CognitoUserPoolId`
- `CognitoUserPoolClientId`
- `CognitoDomain`
- `CognitoIssuer`
- `ThumbnailProcessorName`

## Thumbnail Processor Details

`infrastructure/lambda/thumbnail-processor.ts`:

- Triggered by `OBJECT_CREATED` events in the storage bucket
- Skips non-image uploads and existing thumbnail paths
- Generates JPEG thumbnails (`320x320`) with Jimp
- Writes thumbnail to `{userId}/{fileId}/thumbs/latest.jpg`
- Updates DynamoDB item with `thumbnailKey` and `thumbnailStatus = READY`

## IAM Permissions (Runtime)

The runtime principal used by Next.js server APIs needs at minimum:

- S3: `GetObject`, `PutObject`, `DeleteObject` on your bucket objects
- DynamoDB: `GetItem`, `PutItem`, `UpdateItem`, `DeleteItem`, `Query` on your files table

Prefer IAM roles in deployed environments. Use static keys only for local development.

## Common Troubleshooting

- `Unauthorized` API responses:
	- Confirm sign-in completed and session cookie exists
	- Verify Cognito callback URL matches current app URL
- Upload URL works but upload fails:
	- Check bucket CORS and `Content-Type` sent by browser
- Thumbnails do not appear:
	- Confirm Lambda deployed and triggered by S3 events
	- Check Lambda logs for image parsing errors
- Environment parsing errors on startup:
	- Ensure required env vars are present and non-empty

## Notes

- This app is AWS-centric by design.
- The stack uses `RemovalPolicy.DESTROY` for lab/development convenience.
- For production hardening, consider:
	- Retained storage policies and backups
	- Narrower bucket CORS origins
	- Fine-grained IAM roles
	- Pagination and indexing strategy for large datasets
