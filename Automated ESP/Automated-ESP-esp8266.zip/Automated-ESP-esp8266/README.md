# ESP8266 Aquarium Control System

## Overview

The ESP8266 Aquarium Control System is a comprehensive automation solution designed to control multiple relays for managing aquarium equipment. Built on the ESP8266 platform, this system provides both web-based and physical control interfaces, scheduled operations, and robust error handling capabilities.

## Features

### Core Functionality
- **Web Interface**: Control relays through an intuitive browser-based dashboard
- **Physical Controls**: Toggle relays using physical buttons for immediate access
- **Time-Based Scheduling**: Set daily or weekly schedules for each relay
- **Persistent Storage**: All schedules are saved to EEPROM and survive power cycles
- **WebSocket Support**: Real-time updates across connected clients

### Reliability Features
- **Watchdog Timer**: Automatic system restart if the device becomes unresponsive
- **Error Handling**: Visual indicators for system errors with logging
- **NTP Time Synchronization**: Accurate timekeeping for schedule execution
- **Schedule Conflict Detection**: Prevents conflicting schedules on the same relay
- **WiFi Resilience**: Continues functioning even when WiFi connectivity is lost

### Security
- **Authentication**: Password protection for the web interface
- **IP Whitelisting**: Allow specific IP addresses without authentication
- **Secure WebSockets**: Real-time communication between clients and the device

## Hardware Requirements

- ESP8266-based board (NodeMCU, Wemos D1 Mini, etc.)
- 3-channel relay module
- 3 physical toggle switches
- Status LED for error indication
- Power supply (5V DC)

## Wiring Diagram

```
ESP8266 Pin Mapping:
- D1 (GPIO16): Relay 1
- D2 (GPIO5): Relay 2
- D3 (GPIO4): Relay 3
- D5 (GPIO14): Switch 1
- D6 (GPIO12): Switch 2
- RX (GPIO3): Switch 3
- D7 (GPIO13): Error LED
```

## Software Setup

1. **Configure WiFi Settings**:
   Edit the following lines in the code:
   ```cpp
   const char* ssid = "Your_WiFi_SSID";
   const char* password = "Your_WiFi_Password";
   ```

2. **Set Authentication Credentials**:
   ```cpp
   const char* authUsername = "admin";
   const char* authPassword = "12345678";
   ```

3. **Configure Allowed IP Addresses**:
   ```cpp
   const std::vector<String> allowedIPs = {
     "192.168.29.3",  // Device 1
     "192.168.29.4",  // Device 2
     // Add more IPs as needed
   };
   ```

4. **Upload the Code**:
   Use the Arduino IDE or PlatformIO to compile and upload the code to your ESP8266 device.

## Web Interface

The system provides a responsive web interface accessible at the device's IP address. The interface includes:

- **Relay Control**: Toggle buttons for each relay
- **Schedule Management**: Add, edit, delete, and enable/disable schedules
- **Time Display**: Current time and date synchronized from NTP
- **System Logs**: View system events and errors
- **Error Notification**: Visual indicators for system errors

## Scheduling System

The scheduling system allows you to:

- Create time-based schedules for each relay
- Select specific days of the week for each schedule
- Set separate on and off times
- Enable or disable schedules without deleting them
- Automatically resume schedules after power loss
- Avoid scheduling conflicts

## Troubleshooting

- **Error LED On**: Indicates system error; check logs for details
- **Cannot Connect to Web Interface**: Verify WiFi connection and device IP address
- **Schedules Not Running**: Ensure time synchronization is successful
- **Device Unresponsive**: The watchdog timer should restart the device automatically

## License

This project is licensed under the MIT License - see the LICENSE file for details.

